var SonAccount = /** @class */ (function () {
    function SonAccount(_name, _surname, _balanceInit) {
        this.balanceInit = 0;
        this.name = _name;
        this.surname = _surname;
        this.balanceInit = _balanceInit;
    }
    SonAccount.prototype.deposit = function (add) {
        return this.balanceInit = this.balanceInit + add;
    };
    ;
    SonAccount.prototype.withDraw = function (minus) {
        return this.balanceInit = this.balanceInit - minus;
    };
    ;
    return SonAccount;
}());
var MotherAccount = /** @class */ (function () {
    function MotherAccount(_name, _surname, _balanceInit) {
        this.balanceInit = 0;
        this.name = _name;
        this.surname = _surname;
        this.balanceInit = _balanceInit;
    }
    MotherAccount.prototype.deposit = function (add) {
        return this.balanceInit = this.balanceInit + add;
    };
    ;
    MotherAccount.prototype.withDraw = function (minus) {
        return this.balanceInit = this.balanceInit - (minus + ((minus / 100) * 10));
    };
    ;
    return MotherAccount;
}());
var userSon = new SonAccount('Federico', 'Caramanti', 1000);
var userMother = new MotherAccount('Giulia', 'Durando', 1000);
console.log(userSon.deposit(500));
console.log(userSon.withDraw(700));
console.log(userMother.deposit(500));
console.log(userMother.withDraw(700));
